import 功能库 as main
def do(func,args):
	return func(*args)
func=main.functions
main.start()
path='/storage/emulated/0'
while True:
	try:
		end=input(f'[{path}]>>>')
		args=end.split(' ')
		args[0]=path
		res=do(func[end.split(' ')[0]],args)
		if res:
			path=res
	except:
		main.error('无效的命令')