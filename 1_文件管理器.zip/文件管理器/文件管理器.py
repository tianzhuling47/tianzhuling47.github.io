import 功能库 as main
import platform,os
def do(func,args):
	return func(*args)
func=main.functions
main.start()
main.ok('参数传递时，支持用\space代替路径中的空格\n一次执行多个命令以;分割\nhelp命令帮助系统')
path='/storage/emulated/0'
system=platform.system()
if system =='Linux':
	if os.path.exists('/system'):
		path='/storage/emulated/0'
	else:
		path='/'
elif system=='Windows':
	path=input('初始路径:')
while True:
	end=input(f'[{path}]>>>')
	if end=='help':
	    print("同目录下文档.txt")
		print('''所有的命令都是以空格分开，第一个为命令主体，其余都为参数
dir
参数:无
功能:获取当前目录下的所有文件及文件夹
exists
参数:path
功能:获取path是否存在
remove
参数:无
功能:仅删除文件
remove_folder
参数:无
功能:仅删除文件夹
to
参数:path
功能:跳转到path
提示:path可以是绝对路径，相对路径前面不能加 / 可供安卓和Linux系统使用，Windows系统考虑使用go命令
go
参数:path
功能:跳转到path
提示:Path可以是绝对路径，如果是相对路径，请在最前面加上 .
copy
参数:path
功能:仅将文件复制到path，其中path，复制后的绝对路径
copy_folder
参数:path
功能:仅将文件夹复制到path，其中path，复制后的绝对路径
up
参数:无
功能:跳转到当前目录的上级目录
move
参数:path
功能:将文件转移到path路径
move_folder
参数:path
功能:将文件夹转到path路径''')

	dos=end.split(';')
	for ds in dos:
		args=ds.split(' ')
		args[0]=path
		num=0
		for i in args:
			num+=1
			if '\space' in i:
				args[num-1]=args[num-1].replace('\space',' ')
		if ds.split(' ')[0] in func:
			res=do(func[ds.split(' ')[0]],args)
			if res:
				path=res
		else:
			main.error(f'{ds.split(" ")[0]}命令不存在')