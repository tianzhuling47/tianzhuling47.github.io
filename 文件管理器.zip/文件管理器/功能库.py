import os
green='\033[92m'
red='\033[91m'
white='\033[0m'
yellow='\033[33m'
def start():
	if os.path.exists('回收站')==False:
		os.mkdir('回收站')
	ok('删除的文件将放到回收站(当前目录的回收站文件夹)')
def error(content):
	print(f'{red}错误:{content}{white}')
def ok(content):
	print(f'{green}成功:{content}{white}')
def warning(content,ask=False):
	print(f'{yellow}警告:{content}{white}')
	if ask:
		return  input(f'{yellow}我坚持此操作({ask}):{white}')
def go(path):
    return path
def dir(path,display=True):
	if os.path.isdir(path):
		dirs=os.listdir(path)
		files=[]
		folders=[]
		for i in dirs:
			if os.path.isfile(os.path.join(path,i)):
				files.append(i)
			else:
				folders.append(i)
		if display:
			for i in folders:
				print(f'{red}/文件夹/{green}{i}{white}')
			for i in files:
				if '.' in i and i[0]!='.':
					print(f'{red}/{i.split(".")[-1]}/{white}{i}')
				else:
					print(f'{red}/无/{white}{i}')
		else:
			return [folders,files]		
	else:
		error('不可以对文件使用')
def exists(path):
	if os.path.exists(path):
		ok(f'"{path}"是存在的')
	else:
		ok(f'"{path}"是不存在的')
def put_tr(path):
	with open(path,'rb')as f:
		content=f.read()
	folders,files=dir('回收站',display=False)
	name=os.path.basename(path)
	while name in folders:
		name='_'+name
	os.mkdir(f'回收站/{name}')
	with open(f'回收站/{name}/path.txt','wt',encoding='utf-8')as f:
		f.write(path)
	with open(f'回收站/{name}/index','wb')as f:
		f.write(content)
def remove(path,display=True):
	if os.path.exists(path):
		if os.path.isfile(path):
			if display:
				if warning('你将删除此文件',ask='是否删除Y/n')=='Y':
					put_tr(path)
					os.remove(path)
					ok('删除成功')
			else:
				put_tr(path)
				os.remove(path)
		else:
			error('此方法不可删除文件夹')
def list_files_and_folders(directory):
    files=[]
    for entry in os.listdir(directory):
        full_path = os.path.join(directory, entry)
        if os.path.isfile(full_path):
            files.append(full_path)
def get_all_dir(path):
	files=[]
	for i in os.listdir(path):
	    if os.path.isfile(os.path.join(path,i)):
	    	files.append(os.path.join(path,i))
	    else:
	    	files.extend(get_all_dir(os.path.join(path,i)))
	return files
def delete_empty_folders(folder_path):
    # 遍历目录树（从下往上处理）
    for root, dirs, files in os.walk(folder_path, topdown=False):
        try:
            # 检查是否为空文件夹（排除隐藏文件）		
         
            if not os.listdir(root):
                os.rmdir(root)
        except Exception as e:
            print(f"删除失败: {root} - {str(e)}")
def remove_folder(path,display=True):
	if os.path.isdir(path):
		files=get_all_dir(path)
		if display:
			st=warning(f'此文件夹下共有{str(len(files))}个文件',ask='是否删除该文件夹Y/n')
		else:
			st='Y'
		if st=='Y':
			for i in files:
				remove(i,display=False)
			delete_empty_folders(path)
			if display:
				ok('删除成功')
		
	else:
		error('该方法只能对文件夹使用')
def to(path,s):
	if s[0]=='/':
		if os.path.exists(s):
			return s.rstrip('/')
		else:
			error('路径不存在 ')
			return path.rstrip('/')
	else:
		if os.path.exists(os.path.join(path,s)):
			return os.path.join(path,s).rstrip('/')
		else:
			error('路径不存在 ')
			return path.rstrip('/')
def up(path):
	return os.path.dirname(path)
def copy(path,elpath,display=True):
	if os.path.isfile(path):
		if not os.path.exists(elpath):
			with open(path,'rb')as f:
				content=f.read()
			with open(elpath,'wb')as f:
				f.write(content)
			if display:
				ok('拷贝成功')
		else:
			error('目标目录已存在相同名称的文件')
	else:
		error('此方法只能拷贝文件')
def move(path,elpath):
	if os.path.isfile(path):
		if not os.path.exists(elpath):
			os.rename(path,elpath)
			ok('移动(重命名)成功')
		else:
			error('目标目录已存在相同名称的文件')
	else:
		error('此方法只能移动(重命名)文件 ')
def rename(path,name):
	move(path,os.path.join(up(path),name))
def get_tree(path):
	folders=[]
	tree=[]
	for i in os.listdir(path):
	    if os.path.isfile(os.path.join(path,i)):
	    	tree.append(os.path.join(path,i))
	    else:
	    	folders.append(os.path.join(path,i))
	    	tree.extend(get_tree(os.path.join(path,i))[0])
	return [tree,folders]
def copy_folder(path,elpath,display=True,rename=False):
	if os.path.isdir(path):
		if os.path.isdir(elpath):
			tree,folder=get_tree(path)
			if rename:
				t_name=rename
			else:
				t_name=os.path.basename(path)
			if not os.path.exists(os.path.join(elpath,t_name)):
				if rename:
					os.mkdir(os.path.join(elpath,rename))
				else:
					os.mkdir(os.path.join(elpath,os.path.basename(path)))
			else:
				error('目标目录已存在同名文件夹')
				return 
		else:
			error('目标路径必须是文件夹')
		
			return 
		if not rename:
			t_name=os.path.basename(path)
		else:
			t_name=rename
		for i in folder:
			
			os.mkdir(os.path.join(os.path.join(elpath,t_name),i.split(path)[1].lstrip('/')))
		name=os.path.basename(path)
		for i in tree:
			copy(i,os.path.join(os.path.join(elpath,name),i.split(path)[1].lstrip('/')),display=False)
		if display:
			ok('拷贝成功')
		
	else:
		error('此方法只能拷贝文件夹 ')
def move_folder(path,elpath,rename=False):
	if os.path.isdir(path):
		if os.path.isdir(elpath):
			copy_folder(path,elpath,display=False,rename=rename)
			remove_folder(path,display=False)
			ok('移动(重命名)成功')
		else:
			error('目标路径必须是文件夹')
	else:
		error('此方法只能拷贝文件夹 ')
def rename_folder(path,name):
	if os.path.isdir(path):
		move_folder(path,elpath=up(path),rename=name)
	else:
		error('此方法只能重命名文件夹')

functions=globals()
if __name__=='__main__':
	pass